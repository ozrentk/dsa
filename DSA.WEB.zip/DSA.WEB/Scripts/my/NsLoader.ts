﻿class NsLoader {
    private _namespaces: string[] = [];
    private _scriptEls: HTMLScriptElement[];
    private _domMutationObserver: any;

    private constructor(namespaces: string[])
    {
        this._namespaces = namespaces;
        this._scriptEls = [];
    }

    public static WaitFor(...namespaces: string[]): NsLoader {
        return new NsLoader(namespaces);
    }

    public ContinueWith(continuation: () => void): void {
        if (this.EnsureNamespaces()) {
            continuation();
        }
        else {
            this._scriptEls = <HTMLScriptElement[]><any>document.getElementsByTagName('script');
            this.AttachScriptLoadeds(continuation);
            this.AttachDomMutation(continuation);
        }
    }

    private EnsureNamespaces(): boolean {
        for (var key in this._namespaces) {
            if (eval("typeof " + this._namespaces[key]) === 'undefined') {
                return false;
            }
        }
        return true;
    }

    private AttachScriptLoadeds(continuation: () => void): void {
        for (var key in this._scriptEls) {
            if (typeof this._scriptEls[key] !== 'object')
                continue;

            this._scriptEls[key].addEventListener('load', () => this.ContinueIfLoaded(continuation));
        }
    }

    private AttachDomMutation(continuation: () => void): void {
        var MutationObserver: any = window["MutationObserver"] || window["WebKitMutationObserver"];
        var that = this;
        this._domMutationObserver = new MutationObserver(function (mutations, observer) {
            var scriptsMutated: boolean = false;
            for (var i = 0; i < mutations.length; i++) {
                for (var j = 0; j < mutations[i].addedNodes.length; j++) {
                    if (mutations[i].addedNodes[j].tagName === 'SCRIPT') {
                        console.log("DOM mutation occurred for <script> tag...", mutations[i].addedNodes[j].src);
                        scriptsMutated = true;
                        mutations[i].addedNodes[j].addEventListener('load', () => that.ContinueIfLoaded(continuation));
                    }
                }
            }
        });
        this._domMutationObserver.observe(document, { childList: true, subtree: true });
    }

    private DetachScriptLoadeds(): void {
        for (var key in this._scriptEls)
            if (typeof this._scriptEls[key] === 'object')
                this._scriptEls[key].removeEventListener('load', () => true);
    }

    private DetachDomMutation(): void {
        this._domMutationObserver.disconnect();
    }

    private ContinueIfLoaded(continuation: () => void): void {
        if (this.EnsureNamespaces()) {
            this.DetachScriptLoadeds();
            this.DetachDomMutation();
            continuation();
        }
    }
}

export { NsLoader }