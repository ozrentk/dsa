﻿main = typeof main !== 'undefined' ? main : {};
main.test1 = main.test1 || {};
console.log("loaded main.test1");

main.test1.pozdravi = function () {
    console.log("bokić!");
}
console.log("loaded main.test1.pozdravi");
