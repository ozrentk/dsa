﻿/// <reference path="knockout-3.4.2.js" />
/// <reference path="jquery-3.1.1.js" />

require.config({
    baseUrl: '/Scripts',
    paths: {
        // "module ID": "path to the JS file, relative to baseUrl without .js"
        jquery: 'jquery-3.1.1',
        knockout: 'knockout-3.4.2',
    }
});