﻿using DSA.WEB.Models;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http;

namespace DSA.WEB.Controllers.Authenticate
{
    public class AuthenticateApiController : ApiController
    {
        [Route("api/authenticate/login")]
        [HttpPost]
        public IHttpActionResult LoginJwt(LoginRequest request)
        {
            

            if (request.Username == "djuro" && request.Password == "zguro")
            {
                var loginJwt = new LoginResponse
                {
                    Jwt = "123478c23n91t964x43"
                };

                return Ok(loginJwt);
            }

            return Unauthorized();
        }

        public const string SecretKey = "856FECBA3B06519C8DDDBC80BB080553"; // your symmetric

        public static string GenerateToken(string username, int expireMinutes = 20)
        {
            var symmetricKey = Convert.FromBase64String(SecretKey);
            var tokenHandler = new JwtSecurityTokenHandler();

            var now = DateTime.UtcNow;
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = 
                    new ClaimsIdentity(
                        new[] {
                            new Claim(ClaimTypes.Name, username) }),
                Expires = 
                    now.AddMinutes(
                        Convert.ToInt32(expireMinutes)),
                SigningCredentials = 
                    new SigningCredentials(
                        new SymmetricSecurityKey(symmetricKey), 
                        SecurityAlgorithms.HmacSha256Signature)
            };

            var stoken = tokenHandler.CreateToken(tokenDescriptor);
            var token = tokenHandler.WriteToken(stoken);

            return token;
        }
    }

}
