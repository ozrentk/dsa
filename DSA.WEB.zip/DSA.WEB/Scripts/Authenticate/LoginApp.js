define(["require", "exports", "knockout", "Authenticate/LoginRequestViewModel"], function (require, exports, ko, vms) {
    "use strict";
    exports.__esModule = true;
    var LoginApp = (function () {
        function LoginApp() {
        }
        LoginApp.prototype.Init = function () {
            var vm = new vms.LoginRequestViewModel({ Username: "", Password: "" });
            ko.applyBindings(vm);
            console.log("ko.applyBindings(vm) done.");
        };
        return LoginApp;
    }());
    exports.LoginApp = LoginApp;
});
//# sourceMappingURL=LoginApp.js.map