define(["require", "exports", "knockout", "jquery"], function (require, exports, ko, $) {
    "use strict";
    exports.__esModule = true;
    var LoginRequestViewModel = (function () {
        function LoginRequestViewModel(viewModel) {
            this.Username = ko.observable(viewModel.Username);
            this.Password = ko.observable(viewModel.Password);
        }
        LoginRequestViewModel.prototype.loginRequest = function () {
            $.ajax({
                type: "POST",
                url: "/api/authenticate/login",
                data: ko.toJSON(this),
                contentType: "application/json"
            })
                .done(this.loginSuccess)
                .fail(this.loginFail);
            return false; // don't submit anything
        };
        LoginRequestViewModel.prototype.loginSuccess = function (data, status, xhr) {
            // Check for stupid WebApi handling of "Unauthorized()"
            if (xhr.getResponseHeader("X-Responded-JSON")) {
                var hdr = JSON.parse(xhr.getResponseHeader("X-Responded-JSON"));
                if (+hdr.status == 401) {
                    throw ("Login: unauthorized");
                }
            }
            console.log(status, data.Jwt, xhr);
        };
        LoginRequestViewModel.prototype.loginFail = function () {
            throw ("Login: error");
        };
        return LoginRequestViewModel;
    }());
    exports.LoginRequestViewModel = LoginRequestViewModel;
});
//# sourceMappingURL=LoginRequestViewModel.js.map