define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
    var NsLoader = (function () {
        function NsLoader(namespaces) {
            this._namespaces = [];
            this._namespaces = namespaces;
            this._scriptEls = [];
        }
        NsLoader.WaitFor = function () {
            var namespaces = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                namespaces[_i] = arguments[_i];
            }
            return new NsLoader(namespaces);
        };
        NsLoader.prototype.ContinueWith = function (continuation) {
            if (this.EnsureNamespaces()) {
                continuation();
            }
            else {
                this._scriptEls = document.getElementsByTagName('script');
                this.AttachScriptLoadeds(continuation);
                this.AttachDomMutation(continuation);
            }
        };
        NsLoader.prototype.EnsureNamespaces = function () {
            for (var key in this._namespaces) {
                if (eval("typeof " + this._namespaces[key]) === 'undefined') {
                    return false;
                }
            }
            return true;
        };
        NsLoader.prototype.AttachScriptLoadeds = function (continuation) {
            var _this = this;
            for (var key in this._scriptEls) {
                if (typeof this._scriptEls[key] !== 'object')
                    continue;
                this._scriptEls[key].addEventListener('load', function () { return _this.ContinueIfLoaded(continuation); });
            }
        };
        NsLoader.prototype.AttachDomMutation = function (continuation) {
            var MutationObserver = window["MutationObserver"] || window["WebKitMutationObserver"];
            var that = this;
            this._domMutationObserver = new MutationObserver(function (mutations, observer) {
                var scriptsMutated = false;
                for (var i = 0; i < mutations.length; i++) {
                    for (var j = 0; j < mutations[i].addedNodes.length; j++) {
                        if (mutations[i].addedNodes[j].tagName === 'SCRIPT') {
                            console.log("DOM mutation occurred for <script> tag...", mutations[i].addedNodes[j].src);
                            scriptsMutated = true;
                            mutations[i].addedNodes[j].addEventListener('load', function () { return that.ContinueIfLoaded(continuation); });
                        }
                    }
                }
            });
            this._domMutationObserver.observe(document, { childList: true, subtree: true });
        };
        NsLoader.prototype.DetachScriptLoadeds = function () {
            for (var key in this._scriptEls)
                if (typeof this._scriptEls[key] === 'object')
                    this._scriptEls[key].removeEventListener('load', function () { return true; });
        };
        NsLoader.prototype.DetachDomMutation = function () {
            this._domMutationObserver.disconnect();
        };
        NsLoader.prototype.ContinueIfLoaded = function (continuation) {
            if (this.EnsureNamespaces()) {
                this.DetachScriptLoadeds();
                this.DetachDomMutation();
                continuation();
            }
        };
        return NsLoader;
    }());
    exports.NsLoader = NsLoader;
});
//# sourceMappingURL=NsLoader.js.map