﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace DSA.WEB.Models.Identity
{
    public class DsaAppUserClaim : IdentityUserClaim<int>
    {
    }
}