﻿main = typeof main !== 'undefined' ?  main : {};
main.test2 = main.test2 || {};
console.log("loaded main.test2");

main.test2.pozdravi = function () {
    console.log("di si?");
}
console.log("loaded main.test2.pozdravi");
