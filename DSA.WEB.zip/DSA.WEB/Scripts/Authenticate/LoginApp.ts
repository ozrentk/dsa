﻿import * as ko from "knockout";
import * as vms from "Authenticate/LoginRequestViewModel";

class LoginApp {
    Init() {
        var vm = new vms.LoginRequestViewModel({ Username: "", Password: "" });
        ko.applyBindings(vm);
        console.log("ko.applyBindings(vm) done.")
    }
}

export { LoginApp }